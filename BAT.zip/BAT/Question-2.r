#############################################################################################
#Q2:                                                                                        #
#Execution steps:                                                                           #
#step1 : Place the file in a directory of your choice and execute the script from jupyter   #                                       
#step2 : pass input user argument : directory of the souce file.                            #
#step3 : pass input user argument : file_name: batdataset.csv                               #                                              
#                                                                                           #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#############################################################################################

directory_name = readline(prompt="Enter the directory name: ")
file_name = readline(prompt = "Enter the source file name : ")
setwd(directory_name)
data = read.csv(file_name)

###-----Function to calculate z score----------######
cal_z_score = function(file){
    data_int_datatype = data[,sapply(data,is.integer)]   # identify attributes with integer datatypes
    columns = colnames(data_int_datatype)
    for (col in columns){                                 # executing the column names in loop for operations
        Total_sum = sum(data_int_datatype[col])
        cnt = nrow(data_int_datatype[col])
        z_score_val = (data_int_datatype[col]-(Total_sum/cnt))/(sqrt(sum((data_int_datatype[col]-(Total_sum/cnt))^2)/cnt)) #applying z score formula
        print(paste('z_score for ',col,'is-',z_score_val))
    }
}


cal_z_score(file_name)
