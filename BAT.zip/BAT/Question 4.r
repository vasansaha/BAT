#############################################################################################
#Q4:                                                                                        #
#Execution steps:                                                                           #
#step1 : Place the file in a directory of your choice and execute the script from jupyter   #                                       #
#step2 : pass input user argument : directory of the source file.                            #
#step3 : pass input user argument : file_name: batdataset.csv                               #                                              #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#############################################################################################
directory_name = readline(prompt="Enter the directory name: ")
file_name = readline(prompt = "Enter the source file name : ")
setwd(directory_name)
data = read.csv(file_name)

#---------Function to create a test and train with 70-30 ratio----------#
split_test_train = function(file){
    df_male = subset(data, Gender=='M')
    df_female = subset(data,Gender == 'F')
    df_male_top_70 = head(df_male[order(df_male['Gender'],decreasing=T),],.70*nrow(df_male))
    df_female_top_70 = head(df_female[order(df_female['Gender'],decreasing=T),],.70*nrow(df_female))
    Train_data = rbind(df_male_top_70,df_female_top_70) # append both the dataset
    print('----Printing the Train Dataset------')
    print(Train_data)
    Test_data = data[ !(data$Name %in% Train_data$Name), ]
    print('-----Printing the Test Dataset')
    print(Test_data)
    
    
    
}

split_test_train(file_name)



