#############################################################################################
#Q3:                                                                                        #
#Execution steps:                                                                           #
#step1 : Place the file in a directory of your choice and execute the script from jupyter   #                                       #
#step2 : pass input user argument : directory of the souce file.                            #
#step3 : pass input user argument : file_name: batdataset.csv                               #                                              #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#                                                                                           #
############################################################################################

directory_name = readline(prompt="Enter the directory name: ")
file_name = readline(prompt = "Enter the source file name : ")
setwd(directory_name)
data = read.csv(file_name)

#-------Function to perform one hot encoding---########
execute_one_hot_encoding = function(file){
    
    data['Gender_dummy'] = as.integer(data['Gender'] =='F' )    # convert all females to 1 and males to 0 and assign to a new attribute.
    print(data)
}

execute_one_hot_encoding(file_name)
