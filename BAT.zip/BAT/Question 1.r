#############################################################################################
#Q1: Compute the MEAN, STDEV of the numeric columns.                                        #
#create your own script                                                                     #
#Execution steps:                                                                           #
#step1 : Place the file in a directory of your choice and execute the script from jupyter   #                                       #
#step2 : pass input user argument : directory of the souce file.                            #
#step3 : pass input user argument : file_name: batdataset.csv                               #                                              #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#                                                                                           #
############################################################################################
directory_name = readline(prompt="Enter the directory name: ")
file_name = readline(prompt = "Enter the source file name : ")
setwd(directory_name)
data = read.csv(file_name)

###-----Function to calculate mean----------######

cal_mean = function(file_name){
    data_int_datatype = data[,sapply(data,is.integer)]        # identify attributes with integer datatype
    columns = colnames(data_int_datatype)
    for (col in columns) {                                    #executing the column names in loop for operations
        total_sum = sum(data_int_datatype[col])
        cnt = nrow(data_int_datatype[col])
        mean = total_sum/cnt
        print(paste('Mean of:',col,'is-',mean))
    }
    
}

######--Function to calculate standard deviation--#########

cal_std_dev = function(file) {
    data_int_datatype = data[,sapply(data,is.integer)]       # identify attributes with integer datatypes
    columns = colnames(data_int_datatype)
    for (col in columns) {                                   # executing the column names in loop for operations
        total_sum = sum(data_int_datatype[col])
        cnt = nrow(data_int_datatype[col])
        std_dev = sqrt(sum((data_int_datatype[col]-(total_sum/cnt))^2)/cnt)
        print(paste('Std.dev for ',col,'is-',std_dev))
    }
    
}

cal_mean(file_name)
cal_std_dev(file_name)

