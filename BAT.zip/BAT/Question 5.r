#############################################################################################
#Q5:                                                                                        #
#Execution steps:                                                                           #
#step1 : Place the file in a directory of your choice and execute the script from jupyter   #                                       
#step2 : pass input user argument : directory of the souce file.                            #
#step3 : pass input user argument : file_name: batdataset.csv                               #
#Step4: Pass input user argument :  loop_count:100                                          #     
#Step5: Pass the x feature value :                                                                                            #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#############################################################################################
directory_name = readline(prompt="Enter the directory name: ")
file_name = readline(prompt = "Enter the source file name : ")
loop_count = readline(prompt = "Enter the iteration count limit : ")
x = readline(prompt = "Enter the x_feature in the range of 0 to 100:")
setwd(directory_name)
data = read.csv(file_name)

####----Function to calculate the optimal value of m(gradient), c(Intercept),MSE---#######
calc_min_gradient = function(file,x,loop_count){
    y_label = subset(data,select = c("Endtermmarks"))
    y_bar = mean(as.numeric(unlist(y_label)))
    MSE = sum((y_label-y_bar)^2)/nrow(y_label)
    print(paste('MSE from dataset',MSE))
    for (i in 1:loop_count){
        x_feature = as.numeric(x)
        gradient  = runif(1,0,1)
        intercept = runif(1,0,1)
        y_predict = gradient*x_feature + intercept
        MSE_new = sum((y_label - y_predict)^2)/nrow(y_label)
        
        
        if (MSE_new <= MSE){
            
            
            print(paste(' Execution:---',i,' gradient:---',gradient,' intercept:---',intercept,' MSE New:---',MSE_new))
        }
        else {
            print(paste(' Execution:---',i,' gradient:---',gradient,' intercept:---',intercept,' MSE:---',MSE))
            
        }
        
    }
    
}
calc_min_gradient(file_name,x,loop_count)

